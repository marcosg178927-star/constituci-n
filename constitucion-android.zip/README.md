# constitucion — Proyecto Android

## Opción 1 (recomendada, sin instalar nada en tu computadora)

1. Crea una cuenta gratis en https://github.com
2. Crea un repositorio nuevo (botón verde "New").
3. Sube TODO el contenido de esta carpeta arrastrándolo a la página del repositorio ("uploading an existing file" / "Add file > Upload files").
4. Ve a la pestaña **"Actions"** de tu repositorio. En unos minutos verás que corre solo un proceso llamado "Build APK".
5. Cuando termine (círculo verde ✅), entra a ese resultado y descarga el archivo comprimido "app-android" — adentro está tu **.apk**.
6. Copia ese .apk a tu celular Android e instálalo (activa "instalar de fuentes desconocidas" si tu celular lo pide).

## Opción 2 (en tu computadora, con Android Studio instalado)

```bash
npm install
npx cap add android
npx cap sync
npx cap open android
```

Esto abre Android Studio. Ahí presionas el botón ▶ (Run) o
"Build > Build APK" para generar el archivo .apk.

## Notas

- El archivo de tu app está en `www/index.html`.
- Si tu página usa el GPS del celular, el navegador pedirá permiso de ubicación automáticamente la primera vez que se abra.
- Puedes cambiar el nombre y el ícono editando `capacitor.config.json` y usando https://github.com/ionic-team/capacitor-assets
